/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<bits/stdc++.h>

using namspace std;

int main{
    int year;
    
    
    if(year %400 == 0)
    {
        cout<<"the given year is leap year"<<endl;
        
    }
    else if(year%4 == 0)
    {
        cout<<"the given year is leap year"<<endl;
        
    }
    else if(year%100 == 0)
    {
        cout<<" the given year is not a leap year"<<endl;
        
    }
    else
    {
        cout<<"'the given year is not leap year"<<endl;
    }
    
    return 0;
}
