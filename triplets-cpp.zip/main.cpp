/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<vector>


using namespace std;

int main()
{
    vector<int>a(3);
    vector<int>b(3);
    int alice_points = 0;
    int bob_points = 0;
    
    for(int i =0;i<3;i++){
        cin>>a[i];
    }

    for(int i = 0;i<3;i++){
        cin>>b[i];
        
    }
    
    
    for(int i = 0;i<3;i++){
        if(a[i]>>b[i]){
            alice_points++;
        }
        else{
            bob_points ++;
        }
    }
    cout<<alice_points<< "/ " <<bob_points<<endl;
    return 0;
    
}
